#Copy over jars required to be loaded after the weblogic server classpath into this folder
#
# Examples can be possibly MySql driver jar, or other application related jars 
# that dont need to be necessarily loaded ahead of the app bits or server 
# but are required for app funcitoning
